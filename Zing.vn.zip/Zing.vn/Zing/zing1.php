<?php
	$conn = mysqli_connect('localhost','root','','bigdata');
	mysqli_set_charset($conn , 'UTF8');

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>NewsZing</title>
	<link rel="icon" href="../BTL/Picture/Z.ico">
	<link rel="stylesheet" type="text/css" href="NewsZing.css">
</head>



<body>
	<header id="zingheader" style="margin-bottom: 100px;">
	<div class="wrapper">
	<hgroup>
		<div class="logo"><a href="/" title="Zing News">Zing News - Tri thức trực tuyến</a></div>
	</hgroup>
	<form name="search" id="searchbox" class="znewsSearch">
	<input type="text" value="Nhập nội dung cần tìm" onblur="if(this.value=='') this.value='Nhập nội dung cần tìm'" onfocus="if(this.value=='Nhập nội dung cần tìm') this.value=''" id="search_keyword" placeholder="Nhập nội dung cần tìm...">
	<button type="submit" id="search_button">Tìm kiếm</button>
	</form>
	<ul class="apps">
	<li class="mp3"><a href="http://mp3.zing.vn" title="Zing MP3" target="_blank">MP3</a></li>
	<li class="tv"><a href="http://tv.zing.vn" title="Zing TV" target="_blank">TV</a></li>
	<li class="me"><a href="http://me.zing.vn" title="Zing Me" target="_blank">ME</a></li></ul>
	<div id="bookmark" style="display: block;"><strong>DATE</strong> <span><?php  $sql = "SELECT CURDATE()" ;
					$res = mysqli_query($conn , $sql);
					$row  = mysqli_fetch_array($res);
					echo $row[0] ;
			?> </span></div>
	</div>
	</header>

</body>
</html>