<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');
	mysqli_set_charset($conn , 'UTF8');

	$id_cm = $_POST['id_cm'];


	$add =  " DELETE FROM CHUYENMUC WHERE IDCMUC = '$id_cm' ";

	if(mysqli_query($conn , $add) == TRUE){
			header("Location:Chuyenmuc.php"); 
		} 
	else{
			header("Location:Addcm.php");
		}

	mysqli_close($conn);

 ?>