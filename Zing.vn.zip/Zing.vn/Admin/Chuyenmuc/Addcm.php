<?php 
        $conn = mysqli_connect('localhost', 'root', '','bigdata');
        mysqli_set_charset($conn , 'UTF8'); // must
        $res = mysqli_query($conn , "select * from IMAGE");
 ?>
<!DOCTYPE html>
<html>
<head style="text-align: center>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Thêm Chuyên Mục</title>
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap-theme.css">

    
</head>
<body>
    <script type="text/javascript" src = "../bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript" src = "../bootstrap/js/jquery-3.2.1.js"></script>

<form action="addcm.php" method="POST">

    <div class="form-group">
        <label for="exampleInputPassword1">Mã Chuyên Mục </label>
        <input type="text" class="form-control" name="id_cm" id="id_cm" placeholder="Nhập Mã Chuyên mục " >
    </div>

    <div class="form-group">
        <label for="exampleInputPassword1">Tên Chuyên Mục </label>
        <input type="text" class="form-control" name="name" id="name" placeholder="Nhập tên chuyên mục " >
    </div>

  <button type="submit" name="submit" class="btn btn-primary"> THÊM </button>
</form>
</body>
</html>
