<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');
	mysqli_set_charset($conn , 'UTF8');

	$idcm = $_POST['id_cm'];
	$name = $_POST['name'];


	$add =  " INSERT INTO CHUYENMUC VALUES ('$idcm','$name','')";

	if(mysqli_query($conn , $add) == TRUE){
			header("Location:Chuyenmuc.php"); 
		} 
	else{
			header("Location:Addcm.php");
		}

	mysqli_close($conn);

 ?>