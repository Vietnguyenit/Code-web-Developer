<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bootstrap 3 Navigation</title>
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap-theme.css">
    <script type="text/javascript" src = "../bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src = "../bootstrap/js/jquery-3.2.1.js"></script>

    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <style type="text/css">
        .example{
            margin: 5px;
        }
    </style>
</head>
<body>
    <div class="example">
            <h2 class="text-center">Freetuts.net - Bootstrap 3 Navigation  - Author Hoài Minh</h2>
            <div id="header">
                <nav class="navbar navbar-inverse">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a href="" class="navbar-brand">Freetuts.net</a>
                    </div>
 
                    <div class="navbar-collapse collapse" id="menu">
                        <ul class="nav navbar-nav">
                            <li><a href="">Trang chủ</a></li>
                            <li><a href="">Giới thiệu</a></li>
                            <li><a href="">Tin tức</a></li>
                            <li><a href="">Thương hiệu</a></li>
                            <li><a href="">Liên hệ</a></li>
                        </ul>
                    </div>
                </nav>
            </div>
                 
    </div>
    </body>
    </html>