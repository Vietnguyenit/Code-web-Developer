<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');
	mysqli_set_charset($conn , 'UTF8');

	$id_dm = $_POST['id_dm'];
	$time = $_POST['time'];
	$title = $_POST['title'];
	$summ = $_POST['summ'];
	$cont1 = $_POST['content1'];
	$cont2 = $_POST['content2'];
	$cont3 = $_POST['content3'];
	$cont4 = $_POST['content4'];
	$id_img = $_POST['id_img'];
	$id_vd = $_POST['id_vd'];
	$reporter = $_POST['reporter'];

$sql = " INSERT INTO BAIVIET VALUES ('' , '$id_dm' , '$time' , '$title' , '$summ' , '$cont1' , '$cont2' , '$cont3' ,'$cont4' , '$id_img' , '$id_vd' , '$reporter')";


	$result = mysqli_query($conn , $sql);
		if ($result) {
    	echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
			}
		else
			{
		   		 echo "<script type='text/javascript'>alert('failed!')</script>";

		   		// header("Location:Baiviet.php");
			}
	mysqli_close($conn);

 ?>
