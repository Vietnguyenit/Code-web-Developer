<?php 

		$conn = mysqli_connect('localhost', 'root', '','bigdata');
		mysqli_set_charset($conn , 'UTF8'); // must
		$res = mysqli_query($conn , "select * from BAIVIET");

 ?>
<!DOCTYPE html>
<html>
<head style="text-align: center>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> Bài Viết </title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap-theme.css">
</head>
<body>
	<script type="text/javascript" src = "../bootstrap/js/bootstrap.js"></script>
	<script type="text/javascript" src = "../bootstrap/js/jquery-3.2.1.js"></script>

	<script type="text/javascript">
    $(document).ready(function() {
        $('#loadBv').click(function(e) {
            e.preventDefault();
            $('#bv').load('baiviet.php');
        });
    });
    </script>

	<script type="text/javascript">
    $(document).ready(function() {
        $('#loadbv').click(function(e) {
            e.preventDefault();
            $('#bv').load('AddBv.php');
        });
    });
    </script>

    <script type="text/javascript">
    $(document).ready(function() {
        $('#loadimg').click(function(e) {
            e.preventDefault();
            $('#bv').load('../Image/AddImg.php');
        });
    });
    </script>

    <script type="text/javascript">
    $(document).ready(function() {
        $('#loadvd').click(function(e) {
            e.preventDefault();
            $('#bv').load('../Video/AddVideo.php');
        });
    });
    </script>

<div class="container-fluid" style="width: auto;">
<h3 style="color: cyan ; text-align: center;">Bài Viết </h3>
	 <a id="loadBv"  href="#" title="Bai viet" style="text-decoration: none"">Bài viết |</a> 
	 <a id="loadbv"  href="#" title="Them bai viet" style="text-decoration: none"">Thêm bài viết |</a> 
	 <a id="loadimg"  href="#" title="Them hinh anh" style="text-decoration: none"">Thêm Hình Ảnh |</a>
	 <a id="loadvd"  href="#" title="Them Video" style="text-decoration: none"">Thêm video |</a>  
	 <a href="../Log/success.php" title="Logout" style="text-decoration: none"">Thoát</a>
	 

<form id="bv" style="margin-top: 50px;"></form>


	



	
</div>
</body>
</html>
