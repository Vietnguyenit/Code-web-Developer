<?php 
        $conn = mysqli_connect('localhost', 'root', '','bigdata');
        mysqli_set_charset($conn , 'UTF8'); // must
        $res = mysqli_query($conn , "select * from IMAGE");
 ?>
<!DOCTYPE html>
<html>
<head style="text-align: center>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Thêm Bài Viết</title>
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap-theme.css">

    
</head>
<body>
    <script type="text/javascript" src = "../bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript" src = "../bootstrap/js/jquery-3.2.1.js"></script>

<form action="addBv.php" method="POST">
<h4>Thêm Bài Viết</h4>
  <div class="form-group">
    <label for="exampleInputEmail1">Mã danh mục</label>
        <select class="form-control" id="id_dm" name = "id_dm">
            <?php 
                    $sql = "SELECT * FROM DANHMUC";
                    $res = mysqli_query($conn , $sql);
                  
            while($row = mysqli_fetch_array($res)){
            ?>
              <option value="<?php echo $row[0] ; ?>" >
                <?php
                    echo $row[0] ;
                ?>
                </option>
            <?php } ?>
        </select>
  </div>

  <div class="form-group">
    <label for="exampleInputPassword1">Thời gian</label>
    <input type="date" class="form-control" id="time" name="time" >
  </div>

    <div class="form-group">
    <label for="exampleInputPassword1">Tiêu đề</label>
    <input type="text" class="form-control" name="title" id="title" placeholder="Nhập Tiều đề" >
  </div>


  <div class="form-group">
    <label for="exampleTextarea">Tóm tắt</label>
    <textarea class="form-control" id="summ" name="summ" placeholder="Nội dung tóm tắt" rows="3"></textarea>
  </div>

  <div class="form-group">
    <label for="exampleTextarea">Nội dung 1</label>
    <textarea class="form-control" name="content1" id="content1" rows="5"></textarea>
  </div>

    <div class="form-group">
    <label for="exampleTextarea">Nội dung 2</label>
    <textarea class="form-control" name="content2" id="content2" rows="5"></textarea>
  </div>

    <div class="form-group">
    <label for="exampleTextarea">Nội dung 3</label>
    <textarea class="form-control" name="content3" id="content3" rows="5"></textarea>
  </div>

    <div class="form-group">
    <label for="exampleTextarea">Nội dung 4</label>
    <textarea class="form-control" name="content4" id="content4" rows="5"></textarea>
  </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Mã ảnh</label>
        <select class="form-control" id = "id_img" name = "id_img">
            <?php 
                    $sql = "SELECT * FROM IMAGE";
                    $res = mysqli_query($conn , $sql);
                  
            while($row = mysqli_fetch_array($res)){
            ?>
              <option value="<?php echo $row[0] ; ?>" >
                <?php
                    echo $row[0] ;
                ?>
                </option>
            <?php } ?>
        </select>
  </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Mã Video</label>
        <select class="form-control" id = "id_vd" name = "id_vd">
            <?php 
                    $sql = "SELECT * FROM VIDEO";
                    $res = mysqli_query($conn , $sql);
                  
            while($row = mysqli_fetch_array($res)){
            ?>
              <option value="<?php echo $row[0] ; ?>" >
                <?php
                    echo $row[0] ;
                ?>
                </option>
            <?php } ?>
        </select>
  </div>

  <div class="form-group">
    <label for="exampleInputPassword1">Tên tác giả</label>
    <input type="text" class="form-control" name="reporter" id="reporter" placeholder="Nhập Tên tác giả" >
  </div>



  <button type="submit" name="submit" class="btn btn-primary">THÊM BÀI VIẾT</button>
</form>
</body>
</html>
