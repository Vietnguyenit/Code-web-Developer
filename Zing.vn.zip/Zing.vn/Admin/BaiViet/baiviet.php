<?php 

		$conn = mysqli_connect('localhost', 'root', '','bigdata');
		mysqli_set_charset($conn , 'UTF8'); // must
		$res = mysqli_query($conn , "select * from BAIVIET");

 ?>
<!DOCTYPE html>
<html>
<head style="text-align: center>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> Bài Viết </title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap-theme.css">

	
</head>
<body>
	<script type="text/javascript" src = "../bootstrap/js/bootstrap.js"></script>
	<script type="text/javascript" src = "../bootstrap/js/jquery-3.2.1.js"></script>
<div class="container-fluid" style="width: auto;">
<table class="table table-hover" style="color: green ">
	<thead>
		<tr>
			<th width="90"> Mã Bài Viết</th>
	 		<th width="110"> Mã Danh Mục </th>
	 		<th width="90">Thời Gian </th>
	 		<th width="200">Tiêu đề </th>
	 		<th width="400">Tóm Tắt</th>
	 		<th width="600">Nội dung 1</th>
			<th width="600">Nội dung 2</th>
			<th width="600">Nội dung 3</th>
			<th width="600">Nội dung 4</th>
			<th width="400">Mã Hình ảnh</th>
	 		<th width="40">Mã Video</th>
	 		<th width="80">Tên Tác Giả </th>
	 		<th width="80">Sửa</th>
	 		<th width="80">Xóa</th>
		</tr>
	</thead>
	<?php
	 		while($row = mysqli_fetch_array($res)){
	?>
	<tbody>
		<tr>
			<tr class="content">
			<td><?php echo $row['ID_BAIVIET']; ?></td>
			<td><?php echo $row['ID_DMUC']; ?></td>
			<td><?php echo $row['TIME']; ?></td>
			<td><?php echo $row['TIEUDE']; ?></td>
			<td><?php echo $row['TOMTAT']; ?></td>
			<td><?php echo $row['NOIDUNG1']; ?></td>
			<td><?php echo $row['NOIDUNG2']; ?></td>
			<td><?php echo $row['NOIDUNG3']; ?></td>
			<td><?php echo $row['NOIDUNG4']; ?></td>
			<td><?php echo $row['IDIMG']; ?></td>
			<td><?php echo $row['IDVIDEO']; ?></td>
			<td><?php echo $row['TACGIA']; ?></td>
			<!-- echo "<td><a href='records.php?id=" . $row->id . "'>Edit</a></td>";
			echo "<td><a href='delete.php?id=" . $row->id . "'>Delete</a></td>"; -->
		<td><a href='editBv.php?ID_BAIVIET=".$row->ID_BAIVIET. "' style="text-decoration: none"> Sửa</a></td>
  		<td><a href='delBv.php??ID_BAIVIET=".$row->ID_BAIVIET. "' style="text-decoration: none"> Xóa </a></td>
		</tr>
		<?php 
		}
		 ?>
	</tbody>
</table>
</div>
</body>
</html>