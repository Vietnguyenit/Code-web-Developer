<?php 

        $conn = mysqli_connect('localhost', 'root', '','bigdata');
        mysqli_set_charset($conn , 'UTF8'); // must
        $res = mysqli_query($conn , "select * from IMAGE");

 ?>
<!DOCTYPE html>
<html>
<head style="text-align: center>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Thêm video </title>
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap-theme.css">

    
</head>
<body>
    <script type="text/javascript" src = "../bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript" src = "../bootstrap/js/jquery-3.2.1.js"></script>

<form action="addVideo.php" method="POST">
<h4>Thêm Video</h4>
  <div class="form-group">
    <label for="exampleInputEmail1">Mã Video</label>
        <select class="form-control" id="exampleSelect1" name = "id_dm">
            <?php 
                    $sql = "SELECT * FROM DANHMUC";
                    $res = mysqli_query($conn , $sql);
                  
            while($row = mysqli_fetch_array($res)){
            ?>
              <option value="<?php echo $row[0] ; ?>" >
                <?php
                    echo $row[0] ;
                ?>
                </option>
            <?php } ?>
        </select>
  </div>

  <div class="form-group">
    <label for="exampleInputPassword1">Tên Video</label>
    <input type="text" class="form-control" name="video" id="video" placeholder="Nhập Tên video" >
  </div>


  <div class="form-group">
    <label for="exampleInputPassword1">Video</label>
    <input type="file" class="form-control" name="content" id="content"  >
  </div>

  <button type="submit" name="submit" class="btn btn-primary">THÊM VIDEO</button>
</form>
</body>
</html>
