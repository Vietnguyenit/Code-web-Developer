<?php 

		$conn = mysqli_connect('localhost', 'root', '','bigdata');
		mysqli_set_charset($conn , 'UTF8'); // must
		$res = mysqli_query($conn , "select * from IMAGE");

 ?>
<!DOCTYPE html>
<html>
<head style="text-align: center>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> Video </title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap-theme.css">

	
</head>
<body>
	<script type="text/javascript" src = "../bootstrap/js/bootstrap.js"></script>
	<script type="text/javascript" src = "../bootstrap/js/jquery-3.2.1.js"></script>

<div class="container-fluid">
<h3 style="color: blue ; text-align: center;"> Video </h3>
	<a  href="../BaiViet/AddBv.php" title="Them hinh anh" style="text-decoration: none"">Thêm Bài Viết |
	<a  href="../Image/AddImg.php" title="Them Hinh anh" style="text-decoration: none"">Thêm hình ảnh |</a> 
	<a  href="AddVideo.php" title="Them Video" style="text-decoration: none"">Thêm video |</a>  
	 <a href="../Log/success.php" title="Logout" style="text-decoration: none"">Thoát</a>
<table class="table table-hover" style="color: green ">
	<thead>
		<tr>
			<th width="100"> Mã Video </th>
	 		<th width="100"> Tên Video</th>
	 		<th width="150"> Đường dẫn Video </th>
	 		<th width="30"> Sửa </th>
	 		<th width="30"> Xóa </th>
		</tr>
	</thead>
	<?php
	 		while($row = mysqli_fetch_array($res)){
	?>
	<tbody>
		<tr>
			<tr class="content">
			<td><?php echo $row['IDVIDEO']; ?></td>
			<td><?php echo $row['NAMEVD']; ?></td>
			<td><?php echo $row['CONTENTVD']; ?></td>
			<td><a href='delBv.php?ID_BAIVIET=".$row->ID_BAIVIET. "' style="text-decoration: none"> Sửa</a></td>
  			<td><a href='delBv.php??ID_BAIVIET=".$row->ID_BAIVIET. "' style="text-decoration: none"> Xóa </a></td>
		</tr>
		<?php 
		}
		 ?>
	</tbody>
</table>
	
</div>
</body>
</html>
