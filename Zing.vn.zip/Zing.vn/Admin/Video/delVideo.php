<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');

	$id = $_POST['id_vd'];
	

	$add = "DELETE FORM VIDEO WHERE IDVIDEO = '$id' " ;
		
	if(mysqli_query($conn , $add) == TRUE){
			header("Location:Video.php");
		} 
	else{
			header("Location:AddVideo.php");
		}

	mysqli_close($conn);

 ?>