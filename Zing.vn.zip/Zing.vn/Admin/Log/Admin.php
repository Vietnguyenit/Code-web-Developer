<?php
	if(!isset($_SESSION['currentUser'])){

		header("Location:success.php");
	} else {
		if(!isset($_SESSION['currentAdmin'])){
			header("Location:../BaiViet/Baiviet.php");
		} else{
			echo " Hello ".$_SESSION['currentUser'];
			echo "<a href='Logout.php'>Exit</a>";
		}
	}















  ?>