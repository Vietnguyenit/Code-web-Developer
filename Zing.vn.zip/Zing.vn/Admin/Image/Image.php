<?php 

		$conn = mysqli_connect('localhost', 'root', '','bigdata');
		mysqli_set_charset($conn , 'UTF8'); // must
		$res = mysqli_query($conn , "select * from IMAGE");

 ?>
<!DOCTYPE html>
<html>
<head style="text-align: center>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> Hình Ảnh </title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap-theme.css">

	
</head>
<body>
	<script type="text/javascript" src = "../bootstrap/js/bootstrap.js"></script>
	<script type="text/javascript" src = "../bootstrap/js/jquery-3.2.1.js"></script>

<div class="container-fluid">
<h3 style="color: blue ; text-align: center;"> Hình Ảnh</h3>
	<a  href="../BaiViet/AddBv.php" title="Them hinh anh" style="text-decoration: none"">Thêm Bài Viết |</a> 
	 <a  href="AddImg.php" title="Them hinh anh" style="text-decoration: none"">Thêm Hình Ảnh |</a>
	<a  href="../Video/AddVideo.php" title="Them hinh anh" style="text-decoration: none"">Thêm Video |</a> 
	 <a href="../Log/success.php" title="Logout" style="text-decoration: none"">Thoát</a>
<table class="table table-hover" style="color: green ">
	<thead>
		<tr>
			<th width="100"> Mã Hình Ảnh </th>
	 		<th width="100"> Tên Hình Ảnh</th>
	 		<th width="150"> Đường dẫn ảnh </th>
	 		<th width="100"> Chuyên mục </th>
	 		<th width="60"> Sửa </th>
	 		<th width="60"> Xóa </th>
		</tr>
	</thead>
	<?php
	 		while($row = mysqli_fetch_array($res)){
	?>
	<tbody>
		<tr>
			<tr class="content">
			<td><?php echo $row['IDIMAGE']; ?></td>
			<td><?php echo $row['NAMEIMG']; ?></td>
			<td><?php echo $row['CONTENTIMG']; ?></td>
			<td><?php echo $row['IDCMUC'];?></td>
			<td><a href='editBv.php?ID_BAIVIET=".$row->ID_BAIVIET. "' style="text-decoration: none"> Sửa</a></td>
  			<td><a href='delBv.php??ID_BAIVIET=".$row->ID_BAIVIET. "' style="text-decoration: none"> Xóa </a></td>
		</tr>
		<?php 
		}
		 ?>
	</tbody>
</table>
	
</div>
</body>
</html>