<?php 

        $conn = mysqli_connect('localhost', 'root', '','bigdata');
        mysqli_set_charset($conn , 'UTF8'); // must
        $res = mysqli_query($conn , "select * from IMAGE");

 ?>
<!DOCTYPE html>
<html>
<head style="text-align: center>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Thêm hình ảnh </title>
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap-theme.css">

    
</head>
<body>
    <script type="text/javascript" src = "../bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript" src = "../bootstrap/js/jquery-3.2.1.js"></script>

<form action="addImg.php" method="POST">
<h4>Thêm Hình ảnh</h4>
  <div class="form-group">
    <label for="exampleInputEmail1">Mã hình ảnh</label>
        <select class="form-control" id="exampleSelect1" name = "id_dm">
            <?php 
                    $sql = "SELECT * FROM DANHMUC";
                    $res = mysqli_query($conn , $sql);
                  
            while($row = mysqli_fetch_array($res)){
            ?>
              <option value="<?php echo $row[0] ; ?>" >
                <?php
                    echo $row[0] ;
                ?>
                </option>
            <?php } ?>
        </select>
  </div>

  <div class="form-group">
    <label for="exampleInputPassword1">Tên hình ảnh</label>
    <input type="text" class="form-control" name="img" id="img" placeholder="Nhập Tên Hình ảnh " >
  </div>


  <div class="form-group">
    <label for="exampleInputPassword1">Hình ảnh</label>
    <input type="file" class="form-control" name="content" id="content" placeholder="Nhập đương dẫn" >
  </div>

  <button type="submit" name="submit" class="btn btn-primary">THÊM HÌNH ẢNH</button>
</form>
</body>
</html>
