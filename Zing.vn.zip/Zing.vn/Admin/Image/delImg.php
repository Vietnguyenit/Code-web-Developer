<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');

	$id = $_POST['id_img'];
	

	$add = "DELETE FORM IMAGE WHERE IDIMAGE = '$id' " ;
		
	if(mysqli_query($conn , $add) == TRUE){
			header("Location:Image.php");
		} 
	else{
			header("Location:AddImg.php");
		}

	mysqli_close($conn);

 ?>