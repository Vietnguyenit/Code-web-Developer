<?php	
	$conn = mysqli_connect('localhost','root','','bigdata') 	
	 	 or die("Unable connect to MySQL: " . mysqli_error() ."<br>");	

	 if (isset($_REQUEST['name'])) {	 	

	 	 $query = "SELECT * FROM IMAGE WHERE NAMEI='$_REQUEST[name]'";	
	 	 $q_result = mysqli_query($query) 	
	 	 	 or die("Data retrieval failed" . mysqli_error());	 	 	 	
	 	 $row = mysqli_fetch_array($conn , $q_result);	
	 	 if ($row) {	
	 	 	 header("Content-type:png");	
	 	 	 echo $row['name'];	
	 	 }	
	 	 else 	
	 	 	 echo "Image '$_REQUEST[name]' is not found";	
	 }	
	 else	
	 	 echo "Image name is required"	
?>