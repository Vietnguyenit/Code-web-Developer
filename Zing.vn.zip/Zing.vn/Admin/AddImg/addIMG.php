

<?php  
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');
	$sql= "SELECT * FROM IMG1";
	$result = mysqli_query($conn,$sql);
?>

<?php  
	while ($row = mysqli_fetch_array($result)) {
?>
<div>
	<ul>
		
			<?php echo '<img src="data:image/png;base64,'.base64_encode( $row['CONTENT'] ).'"/>'; ?>
			<!-- <p><?php echo $row['NAME'];?></p> -->
	</ul>
</div>
<?php  }?>