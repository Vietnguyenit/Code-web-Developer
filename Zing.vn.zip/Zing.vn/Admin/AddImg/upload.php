<?php		 /* upload.php */	
	
	 if (($_FILES['up-file']['error'] == 0) &&		 	
	 	
( ($_FILES["up-file"]["type"] == "image/jpg")|| ($_FILES["up-file"]["type"] == "image/png"))){	
	 	
	
	 	 	 move_uploaded_file($_FILES["up-file"]["tmp_name"],	
	 	 	 	 "UPLOAD/" . $_FILES["up-file"]["name"]);	
	 	 	 	 	
	 	 	 echo "File uploaded: " . $_FILES["up-file"]["name"] . "<br>";	
	 	 	 echo "Type: " . $_FILES['up-file']['type'] . "<br>";	
	 	 	 echo "Size: " . $_FILES['up-file']['size'] . "b<br>";		
	 	 	 echo '<img src="UPLOAD/' . $_FILES["up-file"]["name"] . '"/>';	
	 }	
	 else 	
	 	 echo "Upload error: ". $_FILES['up-file']['error'];	
?>