<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');
	mysqli_set_charset($conn , 'UTF8');

	$iddm = $_POST['iddm'];


	$add =  " DELETE FROM DANHMUC WHERE IDCMUC = '$iddm' ";

	if(mysqli_query($conn , $add) == TRUE){
			header("Location:Danhmuc.php"); 
		} 
	else{
			header("Location:Adddm.php");
		}

	mysqli_close($conn);

 ?>