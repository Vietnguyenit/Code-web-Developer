<?php 

    $conn = mysqli_connect('localhost', 'root', '','bigdata');
    mysqli_set_charset($conn , 'UTF8'); // must
    $res = mysqli_query($conn , "select * from DANHMUC");

 ?>
<!DOCTYPE html>
<html>
<head style="text-align: center>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title> Danh mục </title>
  <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap-theme.css">
<style type="text/css">

</style>
  
</head>
<body>
  <script type="text/javascript" src = "../bootstrap/js/bootstrap.js"></script>
  <script type="text/javascript" src = "../bootstrap/js/jquery-3.2.1.js"></script>

<div class="container-fluid">
<h3 style="text-align: center ; color: blue " > Danh mục </h3>
   <a  href="Adddm.php" title="Them danh muc" style="text-decoration: none"">Thêm danh mục |</a> 
   <a href="../Log/success.php" title="Logout" style="text-decoration: none"">Thoát</a>
<table class="table table-hover" style="color: green ">
  <thead>
    <tr>
      <th width="90" > Mã danh mục </th>
      <th width="110"> Tên danh mục </th>
      <th width="80"> Mã chuyên mục </th>
      <th width="80"> Số bài viết </th>
      <th width="80">Sửa</th>
      <th width="80">Xóa</th>
    </tr>
  </thead>
  <?php
      while($row = mysqli_fetch_array($res)){
  ?>
  <tbody>
    <tr>
      <tr class="content">
      <td><?php echo $row['ID_DMUC']; ?></td>
      <td><?php echo $row['TENDANHMUC']; ?></td>
      <td><?php echo $row['IDCMUC']; ?></td>
      <td><?php echo $row['SOBAI']; ?></td>
      <!-- echo "<td><a href='records.php?id=" . $row->id . "'>Edit</a></td>";
      echo "<td><a href='delete.php?id=" . $row->id . "'>Delete</a></td>"; -->
    <td><a href='editBv.php?ID_BAIVIET=".$row->ID_BAIVIET. "' style="text-decoration: none"> Sửa</a></td>
      <td><a href='delBv.php??ID_BAIVIET=".$row->ID_BAIVIET. "' style="text-decoration: none"> Xóa </a></td>
    </tr>
    <?php 
    }
     ?>
  </tbody>
</table>
  
</div>
</body>
</html>
