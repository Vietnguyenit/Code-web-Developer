<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');
	mysqli_set_charset($conn , 'UTF8');

	$id = $_POST['iddm'];
	$name = $_POST['namedm'];
	$idcm = $_POST['idcm'];


	$add =  " UPDATE FROM DANHMUC SET TENDANHMUC = '$name' , IDCMUC = '	$idcm'  WHERE ID_DMUC = '$id'";

	if(mysqli_query($conn , $add) == TRUE){
			header("Location:Danhmuc.php"); 
		} 
	else{
			header("Location:Adddm.php");
		}

	mysqli_close($conn);

 ?>
